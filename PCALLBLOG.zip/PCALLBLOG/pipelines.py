# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html

import PCALLBLOG.pcall.json
from scrapy import signals
from scrapy.exporters import JsonItemExporter
import json
class PcallblogPipeline(object):
    def __init__(self):
        print("!!!!!!!!!!!s")
        self.file = open('pcall.json', 'wb')
        self.exporter = JsonItemExporter(self.file,encoding='utf-8',ensure_ascii=False)
        self.exporter.start_exporting()

    def process_item(self, item, spider):
       # line = json.dumps(dict(item), ensure_ascii=False) + "\n"
       # self.file.write(line)

        self.exporter.export_item(item)
        print("!!!!!! process!!!!")
        return item

    def spider_closed(self, spider):
        print("!!!!!!!!!!end")
        self.exporter.finish_exporting()
        self.file.close()


