# -*- coding: utf-8 -*-
import scrapy
import re
import json
import os
import codecs
from scrapy.http import Request
from urllib import parse
from PCALLBLOG.items import PcallblogItem
from w3lib.html import remove_tags
from scrapy.exporters import JsonItemExporter

class PccnblogSpider(scrapy.Spider):
    name = 'pcallblog'
    allowed_domains = ["blog.jobbole.com"]
    start_urls = ["http://blog.jobbole.com/all-posts/"]
    i=0
    def parse(self, response):
        post_urls = response.xpath(".//*[@class = 'grid-8']/div[@class='post floated-thumb']/div[2]/p/a/@href").extract()
        for post_url in post_urls:
            yield Request(url=parse.urljoin(response.url, post_url), callback=self.parse_detail)

        next_url = response.xpath(".//*[@class = 'grid-8']/div[@class='navigation margin-20']/a[@class= 'next page-numbers']/@href").extract_first("")
        if next_url:
            yield Request(url=parse.urljoin(response.url, next_url), callback=self.parse)

    def parse_detail(self, response):

        item = PcallblogItem()
        item['title'] = response.xpath(".//*[@class = 'entry-header']/h1/text()").extract()[0]
        item['date'] = response.xpath(".//*[@class = 'entry-meta']/p/text()").extract()[0].strip().replace(".", "").strip()
        tag_list = response.xpath(".//*[@class = 'entry-meta']/p/a/text()").extract()
        item['tags'] = ",".join(tag_list)
        item['pra_nums'] = response.xpath(".//*[@class = 'post-adds']/span/h10/text()").extract()[0]
        item['fav_nums'] = response.xpath(".//*[@class = 'post-adds']/span[2]/text()").extract()[0]
        match_re = re.match(".*(\d+).*", item['fav_nums'])
        if match_re:
            item['fav_nums'] = match_re.group(1)
        else:
            item['fav_nums'] = 0
        item['comment_nums'] = response.xpath(".//*[@class='post-adds']/a/span/text()").extract()[0]
        match_re = re.match(".*(\d+).*", item['comment_nums'])
        if match_re:
            item['comment_nums'] = match_re.group(1)
        else:
            item['comment_nums'] = 0

        item['content'] = response.xpath('normalize-space(.//*[@class = "entry"])').extract()[0]
        item['content'] = remove_tags( item['content'] )
        self.print_output(item)
        self.save_my_data( item)
        self.i=self.i+1
        print(self.i)
        if (self.i==100):

            os._exit(0)

    def save_my_data(self,the_item):
        list = []
        with open('data.json','a') as json_file:
            for con in the_item.values():
                list.append(con)
            json_file.write(json.dumps(list,ensure_ascii=False))
            json_file.write('\n')


    def print_output(self, item):
        print("title:", item['title'])
        print("tags:", item['tags'])
        print("date:", item['date'])
        print("pra_nums:", item['pra_nums'])
        print("fav_nums:", item['fav_nums'])
        print("comment_nums:", item['comment_nums'])
       # print("content:", item['content'])



